# 狂人上壽（《東華新報》1899-06-10 第3版，澳洲國家圖書館） / Kuang ren shang shou [A Long-Lived Resident of a Hospital for the Insane]: Transcription Dataset

《東華新報》1899-06-10 刊載的〈狂人上壽〉。報載一名曾受戰傷的男子先後住進兩所醫院達三十九年，九十六歲辭世。文末註明譯自六月二日西報。

Kuang ren shang shou [A Long-Lived Resident of a Hospital for the Insane] appeared in Tung Wah News (1899-06-10). The report describes a man wounded during military service who subsequently spent thirty-nine years in two hospitals and died at the age of ninety-six. The final line credits translation from a Western newspaper dated 2 June.

## V0.1.0

完整收錄第3版此篇原題與正文 3 個原欄，全文格式為 TXT、JSON 與 TEI XML。此版固定 AI 輔助初錄，標明未定讀法。尚未經人類全文雙校。

TXT, JSON and TEI XML cover the complete separately headed article, comprising the heading and 3 source columns on page 3. This edition preserves the first AI-assisted transcription and marks uncertainties. It has not been double proofread by human readers.

## 資料與原件 / Data and source

TXT 供逐欄閱讀，JSON 保留逐幅來源欄位，TEI XML 提供文字層與影像對應。原圖可透過數位館瀏覽。

The TXT, JSON and TEI XML share scan and column references. Images are linked to the institution’s digital viewer.

[館方書目 / Catalogue](https://trove.nla.gov.au/newspaper/page/24102427) · [原圖瀏覽器 / Image viewer](https://trove.nla.gov.au/newspaper/page/24102427)

## 方法與覆核 / Methods and review

由 AI 依固定館方影像逐欄讀字，保留原字、版面與疑讀。照錄原題、時代用字與原欄次。疑讀按欄記在 JSON。人類全文雙校、專家審定、同儕審查及準確率量測尚未進行。實際模型識別與使用量未知。此資料公開供比對與引用，處理程式及影像另存。

An AI assistant transcribed the fixed source images column by column, preserving source forms, layout and uncertain readings. Headings, historical terminology and source column order are preserved. Uncertainties are recorded by column. Human proofreading, expert review, peer review and accuracy measurement are pending. The actual model identifiers and usage are unknown.

## 相關研究 / Related scholarship

- [澳洲國家圖書館著作權期間說明](https://www.library.gov.au/services/copyright-library-collections/how-long-does-copyright-last)
- [Tung Wah Newspaper Index（澳洲報刊英語檢索索引）](https://resources.chineseaustralia.org/tung_wah_newspaper_index)

## 引用及訂正 / Citation and corrections

曲宸宇（Chu, Chen-Yu）整理。引用本版請參考 [CITATION.cff](CITATION.cff)。如有可比對的字形，請附館方影像編號與欄位於 [Issues](https://github.com/poplolioi11/trove24102427-hospital-residence/issues)。權利範圍見 [LICENSE.md](LICENSE.md)。
